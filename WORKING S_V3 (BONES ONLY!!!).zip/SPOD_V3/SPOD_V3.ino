/*******************************************************************************
 * @file    SPOD_V2.ino
 * @brief   Coordinates SPOD sensors, calibration, display, and data logging.
 *
 * @author  Sascha Fowler
 *          Alexander Hansen
 * @cite    Original SPOD.ino, Ankit Kharkanis
 *          Previous editing by Daniel Carranza-Valenzuela
 * @editor  Percy Smith 
 * @date    October 7, 2026
 ******************************************************************************/

#include <Arduino.h>
#include <RTClib.h>
#include <SPI.h>
#include <string.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include "SPOD_node.h"

#if LCDDisplay
  #include "lcd_module.h"
#endif

/*  RTC & File Formatting */
RTC_DS3231 RTC;
#if SD_ENABLED
  #include <SdFat.h>
  SdFat sd;
  File file;
  char fileName[] = "SPODID_YYYY_MM_DD.CSV";
#endif
char bufftime[] = "YYYY-MM-DDThh:mm:ss";
int Y, M, D, h, m, s;


SlowST7735 tft = SlowST7735(&SPI, LCD_CS, LCD_DC, LCD_RST);

void setup(){
  Serial.begin(9600); 

  pinMode(SD_CS, OUTPUT);
  pinMode(LCD_CS, OUTPUT);
  delay(100);
  digitalWrite(SD_CS, HIGH); 
  digitalWrite(LCD_CS, HIGH);
  delay(100);
  tft.initR(INITR_144GREENTAB);
  tft.startWrite();
  tft.setRotation(SPOD_ST7735_ROTATION);
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 42);
  tft.print(spodID);
  tft.endWrite();
  delay(1000);
  Serial.println("LCD Attempted");

  digitalWrite(SD_CS, HIGH); 
  digitalWrite(LCD_CS, HIGH);

  #if SD_ENABLED
    delay(100);
    delay(100);
    sd.begin(SD_CONFIG);
    while (!sd.begin(SD_CONFIG)) 
    {
      #if SERIAL_LOG_ENABLED
        Serial.println(F("SD Initialization Failed"));
      #endif
      sd.begin(SD_CONFIG);
      delay(100);   
    }
    file.open(fileName, O_CREAT | O_APPEND | O_WRITE);
    Serial.println("Through SD");
    file.close();
    delay(1000);
  #endif
  digitalWrite(SD_CS, HIGH); 
  digitalWrite(LCD_CS, HIGH);
  delay(1000);
}

void loop()
{  
    digitalWrite(LCD_CS, HIGH);
    digitalWrite(SD_CS, HIGH);
    delay(1000);

  #if SERIAL_ENABLED
    Serial.println("Looped");
    delay(100);
  #endif

  
  #if LCDDisplay  
    tft.startWrite();
    tft.fillScreen(ST77XX_BLACK);
    tft.setCursor(10, 42);
    tft.print(spodID);
    tft.endWrite();
    delay(1000);
    Serial.println("LCD Attempted");
    digitalWrite(LCD_CS, HIGH);
    digitalWrite(SD_CS, HIGH);
    delay(200);
  #endif

  #if SD_ENABLED
    delay(100);
    Serial.print(F("LCD_CS="));  Serial.println(digitalRead(LCD_CS));
    Serial.print(F("SD_CS="));   Serial.println(digitalRead(SD_CS));
    sd.begin(SD_CONFIG);
    while (!sd.begin(SD_CONFIG)) 
    {
      #if SERIAL_ENABLED
        Serial.println(F("SD Initialization Failed"));
      #endif  
      sd.initErrorPrint(&Serial);
      sd.begin(SD_CONFIG);
      delay(100);   
    }
    file.open(fileName, O_CREAT | O_APPEND | O_WRITE);
    file.println("Data, data, data");
    Serial.println("SD Success");
    file.close();
    delay(100);
  #endif
  
  digitalWrite(SD_CS, HIGH); 
  digitalWrite(LCD_CS, HIGH);
  delay(100);
}