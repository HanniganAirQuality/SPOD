// /*******************************************************************************
//  * @file    lcd_module.cpp
//  * @brief   Module to organize functions for ST7735 LCD display
//  *
//  * @cite    Adapted LCDDisplay.cpp (SPOD)
//  *
//  * @author  Alexander Hansen
//  * @editor  Percy Smith, percy.smith@colorado.edu
//  * @date    October 7, 2026
//  *
//  * @log     Restructured into lab module format (LCD_Module class)
//  *          Removed PCD8544 support (ST7735 only)
//  ******************************************************************************/
// #include "lcd_module.h"

// // #if LCDDisplay

// /**************************************************************************/
//  /*!
//  *    @brief  LCD_Module object; sets status to false by default so begin
//  *            works properly, and binds the ST7735 to its SPOD pins
//  */
// /**************************************************************************/
// LCD_Module::LCD_Module()
//   : tft(LCD_CS, LCD_DC, LCD_RST)
// {
//   status = false;
//   last_update = 0;
//   next_page = 0;
// } //LCD_Module::LCD_Module()

// /**************************************************************************/
//  /*!
//  *    @brief  "begins" the ST7735 display & shows the SPOD ID splash screen
//  *        @param  spod_id string shown on the splash screen
//  *    @return true/false - did display begin? (driver gives no failure
//  *            feedback, so this is true once init completes)
//  */
// /**************************************************************************/
// bool LCD_Module::begin(const char* spod_id)
// {
//   tft.initR(INITR_144GREENTAB);
//   tft.setRotation(SPOD_ST7735_ROTATION);
//   tft.setTextWrap(false);
//   tft.fillScreen(ST77XX_BLACK);
//   tft.setTextColor(ST77XX_CYAN);
//   tft.setTextSize(2);
//   tft.setCursor(10, 42);
//   tft.print(spod_id);
//   delay(1500);
//   tft.fillScreen(ST77XX_BLACK);
//   // last_update = millis() - UPDATE_INTERVAL_MS; // forces draw on first update
//   status = true;

//   return status;
// } //bool LCD_Module::begin(const char* spod_id)

// /**************************************************************************/
//  /*!
//  *    @brief  Picks the label color from the label's first letter
//  *        @param  label label string (e.g. "CO2:", "Soil:")
//  *    @return ST77XX color: C yellow, S green, U magenta, I red, else cyan
//  */
// /**************************************************************************/
// uint16_t LCD_Module::label_color(const char* label)
// {
//   if (label[0] == 'C') return ST77XX_YELLOW;
//   if (label[0] == 'S') return ST77XX_GREEN;
//   if (label[0] == 'U') return ST77XX_MAGENTA;
//   if (label[0] == 'I') return ST77XX_RED;
//   return ST77XX_CYAN;
// } //uint16_t LCD_Module::label_color(const char* label)

// /**************************************************************************/
//  /*!
//  *    @brief  Selects the display (CS low) and blanks the screen
//  */
// /**************************************************************************/
// void LCD_Module::clear_display()
// {
//   tft.fillScreen(ST77XX_BLACK);
// } //void LCD_Module::clear_display()

// /**************************************************************************/
//  /*!
//  *    @brief  Draws test screen 
//  */
// /**************************************************************************/
// void LCD_Module::drawScreen_1() {
//     tft.fillScreen(0x0);
//     // rect 15
//     tft.drawRect(8, 81, 111, 20, 0xFFFF);
//     // rect 15
//     tft.drawRect(8, 19, 111, 20, 0xFFFF);
//     // rect 15
//     tft.drawRect(8, 103, 111, 21, 0xFFFF);
//     // rect 15
//     tft.drawRect(51, 4, 13, 13, 0xFFFF);
//     // rect 15
//     tft.fillRect(54, 7, 7, 7, 0x4D6A);
//     // rect 15
//     tft.drawRect(66, 4, 53, 13, 0xFFFF);
//     // rect 15
//     tft.drawRect(8, 4, 41, 13, 0xFFFF);
//     // rect 10
//     tft.drawRect(8, 41, 111, 38, 0xFFFF);
//     // string 2
//     tft.setTextSize(1);
//     tft.setTextColor(0xFFFF);
//     tft.setTextWrap(false);
//     tft.setCursor(65, 29);
//     tft.print("IR:");
//     // string 2
//     tft.setCursor(11, 69);
//     tft.print("T2:");
//     // string 2
//     tft.setCursor(11, 91);
//     tft.print("CO2:");
//     // string 2
//     tft.setCursor(11, 114);
//     tft.print("Moisture:");
//     // string 2
//     tft.setCursor(11, 106);
//     tft.print("Soil");
//     // string 2
//     tft.setCursor(11, 7);
//     tft.print("SPODY3");
//     // string 2
//     tft.setCursor(69, 7);
//     tft.print("00:00:00");
//     // string 2
//     tft.setCursor(99, 82);
//     tft.print("ppm");
//     // string 2
//     tft.setCursor(111, 107);
//     tft.print("%");
//     // string 2
//     tft.setCursor(111, 65);
//     tft.print("C");
//     // string 2
//     tft.setCursor(111, 47);
//     tft.print("C");
//     // string 2
//     tft.setCursor(11, 29);
//     tft.print("UV:");
//     // string 2
//     tft.setCursor(11, 51);
//     tft.print("T1:");
//     // string 2
//     tft.setTextSize(2);
//     tft.setCursor(28, 22);
//     tft.print("000");
//     // string 2
//     tft.setCursor(36, 44);
//     tft.print("000.00");
//     // string 2
//     tft.setCursor(82, 22);
//     tft.print("000");
//     // string 2
//     tft.setCursor(36, 62);
//     tft.print("000.00");
//     // string 2
//     tft.setCursor(38, 84);
//     tft.print("00000");
//     // string 2
//     tft.setCursor(74, 107);
//     tft.print("100");
//     // // ellipse 26
//     // tft.drawEllipse(109, 63, 1, 1, 0xFFFF);
//     // // ellipse 26
//     // tft.drawEllipse(109, 45, 1, 1, 0xFFFF);
// }
// // [END lopaka generated]

// /**************************************************************************/
//  /*!
//  *    @brief  Draws a single full-screen message
//  *        @param  message text to display
//  */
// /**************************************************************************/
// void LCD_Module::write_message(const char* message)
// {
//   // tft.initR(INITR_144GREENTAB);
//   // tft.setRotation(SPOD_ST7735_ROTATION);
//   tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
//   tft.setTextSize(2);
//   tft.setCursor(2, 52);
//   tft.print(message);
// } //void LCD_Module::write_message(const char* message)

