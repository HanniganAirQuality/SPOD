/*******************************************************************************
 * @file    lcd_module.h
 * @brief   Module to organize functions for ST7735 LCD display
 *
 * @cite    Adapted LCDDisplay.h / LCDDisplay.cpp (SPOD)
 *
 * @author  Alexander Hansen
 * @editor  Percy Smith, percy.smith@colorado.edu
 * @date    October 7, 2026
 *
 * @log     Restructured into lab module format (LCD_Module class)
 *          Removed PCD8544 support (ST7735 only)
 ******************************************************************************/
#ifndef _LCD_MODULE_H
#define _LCD_MODULE_H

#include <Arduino.h>
#include <stdint.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>

#include "SPOD_node.h"

/****************** STRUCTS, OBJECTS ********************/
/*! LCD display input structure (ALL DATA): pre-formatted strings + enable flags */
struct LCD_Data
{
  bool lightEnabled;
  const char* visible;
  const char* infrared;
  const char* uvIndex;

  bool moistureEnabled;
  bool moistureNumeric;
  const char* moisture;

  bool temperature1Enabled;
  const char* temperature1;
  bool temperature2Enabled;
  const char* temperature2;

  bool co2Enabled;
  bool co2Numeric;
  const char* co2;
}; //struct LCD_Data

/*! ST7735 driver forced to the verified slow SPI clock (library default is 32 MHz) */
class SlowST7735 : public Adafruit_ST7735
{
  public:
    SlowST7735(SPIClass *spi, int8_t cs, int8_t dc, int8_t rst)
      : Adafruit_ST7735(spi, cs, dc, rst) {}

    void begin(uint32_t frequency = 0) override
    {
      (void)frequency;
      Adafruit_ST77xx::begin(SPOD_ST7735_SPI_FREQUENCY);
    }
}; //class SlowST7735

/****************** CLASSES ********************/
/*! ST7735 128x128 display; pages through light and environment readings */
// class LCD_Module {
//   public:
//     LCD_Module();
//     bool begin(const char* spod_id);
//     void update(const LCD_Data& data);
//     void write_message(const char* message);
//     void write_output_value(const char* label, const char* value,
//                             const char* units, bool show_units, byte row);
//     void clear_display();
//     void drawScreen_1();

//   private:
//     static const unsigned long UPDATE_INTERVAL_MS = 2000;

//     bool status;
//     unsigned long last_update;
//     byte next_page;

//     uint16_t label_color(const char* label);
//     void show_light_page(const LCD_Data& data);
//     byte environment_reading_count(const LCD_Data& data);
//     void show_environment_page(const LCD_Data& data, byte page);
// };

#endif //_LCD_MODULE_H
